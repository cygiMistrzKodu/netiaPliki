package com.netia.zadanie21;

public class Summary {
	
     /*  PSEUDO CODE   
      
    public void  podsumowanieKwotowe( dane[][] ) {
       
       unikalneIdentyfikatoryPodsumowania[] = pobierzUnikalneIndentyfikatoryPodsumowania(dane[][]);
       kwoty[] = obliczKwoty(unikalneIdentyfikatoryPodsumowania[],dane[][]);
       
       int[] pozycjeSortowania = new int[] {1,2,3};
       posortowaneKwoty[] = sortujKwoty(unikalneIdentyfikatoryPodsumowania[], kwoty[],pozycjeSortowania[] );
       printPodsumowanie(posortowaneKwoty[]);
       
       }
       
       private [] pobierzUnikalneIndentyfikatoryPodsumowania(final dane[][]) {
       
         final int indentyfikatorPodsumowaniaIndex = 3;
         int rozmiar = array_lenght(dane); 
         int[] identyfikatoryPodsumowania = new int[rozmiar];
                
         for ( index = 1 ; index < rozmiar + 1 ; index++ ) {
         
            identyfikatoryPodsumowania[i] = dane[i][indentyfikatorPodsumowaniaIndex];
         
         }
         
         final int unikalneIdentyfikatoryRozmiar = obliczDlugoscBezDuplikatow(identyfikatoryPodsumowania)
         
         int[] unikalneIdentyfkatoryPodsumowania = new int[unikalneIdentyfikatoryRozmiar];
         
         unikalneIdentyfkatoryPodsumowania = usunDuplikaty(identyfikatoryPodsumowania[]); 
       
         return unikalneIdentyfkatoryPodsumowania;
       }
       
       
       
      private [] obliczKwoty(final unikalneIdentyfikatoryPodsumowania[], final dane[][]){
      
          int size = unikalneIdentyfikatoryPodsumowania.length;
          float [] kwoty = new float[size];
          final int rodzajUslugiIndex = 2;
          final int indentyfikatorPodusmowaniaIndex = 3;
          
          int rozmiar = array_lenght(dane);
          
          int indexKwoty = 1;
          for ( indentyfikatorPodusmowania : unikalneIdentyfikatoryPodsumowania[] ) {
          
            for ( index = 1 ; index < rozmiar + 1 ; index++ ) {
         
                 if ( indentyfikatorPodusmowania == dane[index][indentyfikatorPodusmowaniaIndex] ) {
                    kwoty[indexKwoty] += dane[index][rodzajUslugiIndex];
                  }
         
              }
            
            indexKwoty++;
          }
          
          return kwoty;
      }
      
      
      private int obliczDlugoscBezDuplikatow(final tablica[]){
      
            Set<Integer> set = new HashSet<>();
            set.addAll(tablica[]);
            return set.size();
      }
      
     private [] sortujKwoty(final unikalneIdentyfikatoryPodsumowania[], final kwoty[],final pozycjeSortowania[] ) {
     
       rozmiar = kwoty.lenght;
       float  posortowaneKwoty = new float[rozmiar];
      
       for ( index = 1 ; index < rozmiar +1; index++ ) {
         
           if (unikalneIdentyfikatoryPodsumowania[index] == pozycjeSortowania[index] ) {
           
           		posortowaneKwoty[index] = kwoty[index];
           		
           } else {
           
             int pozcyjaSortowania = pozycjeSortowania[index];
             
             int indexKwotyDoSortowania = znajdzIndexKwoty(unikalneIdentyfikatoryPodsumowania[], pozcyjaSortowania);
              
             posortowaneKwoty[index] = kwoty[indexKwotyDoSortowania];
           }
         
         }
     
        return posortowaneKwoty;
     }
     
     private znajdzIndexKwoty(final unikalneIdentyfikatoryPodsumowania[], final pozcyjaSortowania) {
     
         int indexKwotyDoSortowania = 1;
         int dlugosc = unikalneIdentyfikatoryPodsumowania.lenght;
         
         for ( index = 1 ; index < dlugosc + 1 ; index++ ){
         
            if (unikalneIdentyfikatoryPodsumowania[index] == pozcyjaSortowania ) {
               break;
             }
            indexKwotyDoSortowania++;
         }
     
      return indexKwotyDoSortowania;
     }
     
     private void printPodsumowanie(final posortowaneKwoty[]) {
     
     String[] kategoriePodsumowania = new String[] {"Internet", "Us�ugi Dodatkowe", "Telewizja" };
     
      rozmiar = kategoriePodsumowania.length;
     
       for ( index = 1 ; index < rozmiar + 1 ; index++ ) {
         
         System.out.printLn( kategoriePodsumowania[index] +" | "+ posortowaneKwoty[index] );
         
         }
     
     
     }
       
      
      */

}
