﻿
W Odpytaniu jest literówka w nazwie metody :

<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:int="https://netia.pl/">
   <soapenv:Header/>
   <soapenv:Body>
      <int:checkCustomerCreditionals>   <--- Creditonals 
         <username>?</username>
         <password>?</password>
      </int:checkCustomerCreditionals>
   </soapenv:Body>
</soapenv:Envelope>

---------------------------------

Mi wyszło że powinno być : 

<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:int="https://netia.pl/">
   <soapenv:Header/>
   <soapenv:Body>
      <int:checkCustomerCredentials>
         <username>?</username>
         <password>?</password>
      </int:checkCustomerCredentials>
   </soapenv:Body>
</soapenv:Envelope>

---------------------------------------

Url do Serwisu : 

http://localhost:8080/CredWS/InetiaSsoWS

WSDL : 

http://localhost:8080/CredWS/InetiaSsoWS?wsdl

----------------------------------------------

Skompilowania paczka w folderze :  PaczkaWar

----------------------------------------------

Kompilownaie paczki ze żródeł -> mvn clean install