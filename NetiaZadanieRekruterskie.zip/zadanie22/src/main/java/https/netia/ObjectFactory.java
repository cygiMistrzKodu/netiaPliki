
package https.netia;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the https.netia package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CheckCustomerCredentialsResponse_QNAME = new QName("https://netia.pl/", "checkCustomerCredentialsResponse");
    private final static QName _CheckCustomerCredentials_QNAME = new QName("https://netia.pl/", "checkCustomerCredentials");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: https.netia
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CheckCustomerCredentialsResponse }
     * 
     */
    public CheckCustomerCredentialsResponse createCheckCustomerCredentialsResponse() {
        return new CheckCustomerCredentialsResponse();
    }

    /**
     * Create an instance of {@link CheckCustomerCredentials }
     * 
     */
    public CheckCustomerCredentials createCheckCustomerCredentials() {
        return new CheckCustomerCredentials();
    }

    /**
     * Create an instance of {@link CredentialsResponse }
     * 
     */
    public CredentialsResponse createCredentialsResponse() {
        return new CredentialsResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CheckCustomerCredentialsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "https://netia.pl/", name = "checkCustomerCredentialsResponse")
    public JAXBElement<CheckCustomerCredentialsResponse> createCheckCustomerCredentialsResponse(CheckCustomerCredentialsResponse value) {
        return new JAXBElement<CheckCustomerCredentialsResponse>(_CheckCustomerCredentialsResponse_QNAME, CheckCustomerCredentialsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CheckCustomerCredentials }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "https://netia.pl/", name = "checkCustomerCredentials")
    public JAXBElement<CheckCustomerCredentials> createCheckCustomerCredentials(CheckCustomerCredentials value) {
        return new JAXBElement<CheckCustomerCredentials>(_CheckCustomerCredentials_QNAME, CheckCustomerCredentials.class, null, value);
    }

}
