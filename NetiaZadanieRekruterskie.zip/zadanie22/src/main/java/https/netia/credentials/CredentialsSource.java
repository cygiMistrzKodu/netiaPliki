package https.netia.credentials;

import java.util.HashMap;
import java.util.Map;

import https.netia.CredentialsResponse;

public class CredentialsSource {

	private static Map<CustomerCredential, CredentialsResponse> userCredentials = new HashMap<>();

	static {

		userCredentials.put(new CustomerCredential("login1", "pass1"), createResponse(0, "OK"));
		userCredentials.put(new CustomerCredential("login2", "pass2"), createResponse(0, "OK"));
		userCredentials.put(new CustomerCredential("login3", "pass3"), createResponse(0, "OK"));
		userCredentials.put(new CustomerCredential("login8", "du.8"), createResponse(0, "OK"));
		userCredentials.put(new CustomerCredential("login6", "badpass"), createResponse(8, "Account Blocked"));

	}

	private static CredentialsResponse createResponse(int resCode, String resDescription) {
		CredentialsResponse credentialsResponse = new CredentialsResponse();
		credentialsResponse.setResCode(resCode);
		credentialsResponse.setResDescription(resDescription);

		return credentialsResponse;
	}

	public static CredentialsResponse getResponse(final String username, final String password) {

		CredentialsResponse credentialsResponse = userCredentials.get(new CustomerCredential(username, password));

		if (isWrongLogin(credentialsResponse)) {

			credentialsResponse = createResponse(5, "NOT FOUND");

			if (isWrongPassword(username, password)) {

				credentialsResponse = createResponse(1, "Wrong password");
			}

		}

		return credentialsResponse;

	}

	private static boolean isWrongLogin(CredentialsResponse credentialsResponse) {
		return credentialsResponse == null;
	}

	private static boolean isWrongPassword(final String username, final String password) {

		for (CustomerCredential customerCredential : userCredentials.keySet()) {

			if (customerCredential.getUserName().equals(username)) {

				if (customerCredential.getPassword().equals(password)) {

					return false;

				} else {
					return true;
				}

			}

		}

		return false;
	}

}
