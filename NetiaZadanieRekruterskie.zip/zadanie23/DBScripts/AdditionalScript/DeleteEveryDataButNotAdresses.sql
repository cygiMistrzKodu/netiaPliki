﻿

DELETE FROM public.geocode_address_components;
DELETE FROM public.address_component_types;
DELETE FROM public.address_component;

DELETE FROM public.request;
DELETE FROM public.geocode_types;
DELETE FROM public.geocode;

DELETE FROM public.geometry;
DELETE FROM public.area;

DELETE FROM public.location;

DELETE FROM public.geocode_address_components;
