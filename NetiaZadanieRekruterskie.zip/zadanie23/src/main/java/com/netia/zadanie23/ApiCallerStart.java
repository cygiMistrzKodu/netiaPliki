package com.netia.zadanie23;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import com.netia.zadanie23.services.GeoCodeCallerServiceConsumer;
import com.netia.zadanie23.services.GoogleFormatAdressReaderProducer;

@Service
public class ApiCallerStart implements CommandLineRunner {

	@Autowired
	private GoogleFormatAdressReaderProducer googleFormatAdressReaderProducer;
	
	@Autowired
	private GeoCodeCallerServiceConsumer geoCodeCallerServiceConsumer; 

	@Override
	public void run(String... args) throws Exception {

		ExecutorService executor = Executors.newFixedThreadPool(2);
		executor.submit(googleFormatAdressReaderProducer);
		executor.submit(geoCodeCallerServiceConsumer);
		
		executor.shutdown();
		
	}
}
