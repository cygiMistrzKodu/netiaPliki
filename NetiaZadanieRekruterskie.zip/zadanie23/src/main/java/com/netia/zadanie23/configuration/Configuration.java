package com.netia.zadanie23.configuration;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;

import com.netia.zadanie23.databaseModel.Address;

@SpringBootConfiguration
public class Configuration {
	
	@Value("${adress.queue.capacity}")
	private int adressCapacity = 30;
	
	@Bean
	public BlockingQueue<Address>  initilizeAdressesQueue () {	
		return new ArrayBlockingQueue<>(adressCapacity);
	}
	

}
