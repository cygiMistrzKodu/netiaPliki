package com.netia.zadanie23.repositories;

import org.springframework.data.repository.CrudRepository;

import com.netia.zadanie23.databaseModel.Request;

public interface RequestRepository extends CrudRepository<Request, Long> {

}
