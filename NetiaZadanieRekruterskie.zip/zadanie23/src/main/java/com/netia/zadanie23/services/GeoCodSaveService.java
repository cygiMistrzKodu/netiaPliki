package com.netia.zadanie23.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netia.zadanie23.databaseModel.geoCode.Geocode;
import com.netia.zadanie23.repositories.GeoCodeRepository;

@Service
public class GeoCodSaveService {

	@Autowired
	private GeoCodeRepository geoCodeRepository;
	
	
	public void save(Geocode geocode ) {
	 	geoCodeRepository.save(geocode);
	}
	
	

}
