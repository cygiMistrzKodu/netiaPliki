package com.netia.zadanie23.services;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.netia.zadanie23.ResponseModel.GeocodeResponse;
import com.netia.zadanie23.databaseModel.Address;
import com.netia.zadanie23.databaseModel.Request;
import com.netia.zadanie23.databaseModel.Status;
import com.netia.zadanie23.databaseModel.geoCode.Geocode;

@Service
public class GeoCodeCallerServiceConsumer implements Runnable {

	private BlockingQueue<Address> adresses;

	private final static String GOOGLE_API_BASEURL = "https://maps.googleapis.com/maps/api/geocode/json";

	@Value("${google.api.key}")
	private String apiKey;
	
	@Value("${call.interval.miliseconds}")
	private int apiCallInterval;
	
	@Autowired
	private RequestService requestService;
	
	@Autowired
	private ResponseToEntityModelConverter responseToEntityModelConverter;
	
	@Autowired
	private GeoCodSaveService geoCodSaveService;
	
	private final Logger logger = LoggerFactory.getLogger(GeoCodeCallerServiceConsumer.class);

	@Autowired
	public GeoCodeCallerServiceConsumer(BlockingQueue<Address> adresses) {
		super();
		this.adresses = adresses;
	}

	@Override
	public void run() {
		
		String url = GOOGLE_API_BASEURL + "?address={address}" + apiKey;
				
		RestTemplate restTemplate = new RestTemplate();

		Map<String, String> parameters = new HashMap<String, String>();
		final String adressParameter = "address";
		
		while (true) {
			
			try {
				
				Address addressToProcess = adresses.take();
				logger.info("LEFT TO PROCESS : {}", adresses.size());
				
				parameters.put(adressParameter, addressToProcess.getGoogleFormatAdress());
				
				Request request = new Request();
				request.setStatus(Status.PROCESSING);
				request.setAdress(addressToProcess);
				
				requestService.save(request);
				logger.info("Start processing request: - {} - {} : {}",request.getId(), request.getStatus(), addressToProcess.getGoogleFormatAdress());
				
				String response = restTemplate.getForObject(url, String.class, parameters);
				GeocodeResponse geocodeResponse = new Gson().fromJson(response, GeocodeResponse.class);
				logger.info("Response: :\n {} \n ",response);
				Geocode geocode =  responseToEntityModelConverter.translateAndGetGeocode(geocodeResponse.getResults());
				
				geoCodSaveService.save(geocode);
				
				request.setStatus(Status.FINISHED);
				request.setFinishedTimeStamp(LocalDateTime.now());
				request.setGeocode(geocode);
				
				requestService.save(request);
				logger.info("Request saved add response id: {} ",request.getGeocode().getId());
				Thread.sleep(apiCallInterval);
				
				parameters.clear();

			} catch (InterruptedException e) {

				e.printStackTrace();
			}

		}
	}

}
