package com.netia.zadanie23.services;

import java.util.concurrent.BlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.netia.zadanie23.databaseModel.Address;

@Service
public class GoogleFormatAdressReaderProducer implements Runnable {

	private BlockingQueue<Address> adresses;

	@Autowired
	private AdressService adressService;
	
	@Value("${reading.interval.miliseconds}")
	private int readingInterval;
	
	private final Logger logger = LoggerFactory.getLogger(GoogleFormatAdressReaderProducer.class);
	
	@Autowired
	public GoogleFormatAdressReaderProducer(BlockingQueue<Address> adresses) {
		super();
		this.adresses = adresses;
	}

	@Override
	public void run() {

		while (true) {

			logger.info("Try Reading adresses left: {}  to process",adresses.size());
			adressService.getAdressesNotProcessed().stream()
			.map(a -> a)
			.filter(a -> !adresses.contains(a))
			.forEach(a -> adresses.offer(a));
			

			try {
				Thread.sleep(readingInterval);
			} catch (InterruptedException e) {
						

				e.printStackTrace();
			}

		}
	

	}

}
