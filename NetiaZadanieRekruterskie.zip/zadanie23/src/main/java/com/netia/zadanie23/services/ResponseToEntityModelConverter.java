package com.netia.zadanie23.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.netia.zadanie23.databaseModel.geoCode.AddressComponent;
import com.netia.zadanie23.databaseModel.geoCode.Area;
import com.netia.zadanie23.databaseModel.geoCode.Geocode;
import com.netia.zadanie23.databaseModel.geoCode.Geometry;
import com.netia.zadanie23.databaseModel.geoCode.Location;

@Service
public class ResponseToEntityModelConverter {

	public Geocode translateAndGetGeocode(List<com.netia.zadanie23.ResponseModel.Geocode> geocodeResponseList) {

		com.netia.zadanie23.ResponseModel.Geocode geocodeResponse = geocodeResponseList.get(0);

		Geocode geocodeDbModel = new Geocode();

		geocodeDbModel.setTypes(geocodeResponse.getTypes());
		geocodeDbModel.setFormattedAddress(geocodeResponse.getFormatted_address());
		geocodeDbModel.setAddressComponents(translateAdressComponents(geocodeResponse.getAddress_components()));
		geocodeDbModel.setGeometry(translateGeometry(geocodeResponse.getGeometry()));
		geocodeDbModel.setPartialMatch(geocodeResponse.isPartialMatch());

		return geocodeDbModel;
	}

	private List<AddressComponent> translateAdressComponents(
			List<com.netia.zadanie23.ResponseModel.AddressComponent> adressComponentsResponse) {

		return adressComponentsResponse.stream().map(element -> translateAdressComponent(element))
				.collect(Collectors.toList());

	}

	private AddressComponent translateAdressComponent(
			com.netia.zadanie23.ResponseModel.AddressComponent addressComponentResponse) {

		AddressComponent addressDbComponent = new AddressComponent();
		addressDbComponent.setLongName(addressComponentResponse.getLongName());
		addressDbComponent.setShortName(addressComponentResponse.getShortName());
		addressDbComponent.setTypes(addressComponentResponse.getTypes());

		return addressDbComponent;
	}

	private Geometry translateGeometry(com.netia.zadanie23.ResponseModel.Geometry geometryResponse) {

		Geometry geometryDbModel = new Geometry();

		geometryDbModel.setLocation(translateLocation(geometryResponse.getLocation()));
		geometryDbModel.setLocationType(geometryResponse.getLocationType());
		geometryDbModel.setViewport(translateViewPort(Optional.ofNullable(geometryResponse.getViewport())));
		geometryDbModel.setBounds(translateBounds(Optional.ofNullable(geometryResponse.getBounds())));

		return geometryDbModel;
	}

	private Location translateLocation(com.netia.zadanie23.ResponseModel.Location locationResponse) {

		Location locationDbModel = new Location();

		locationDbModel.setLat(locationResponse.getLat());
		locationDbModel.setLng(locationResponse.getLng());

		return locationDbModel;
	}

	private Area translateViewPort(Optional<com.netia.zadanie23.ResponseModel.Area> viewportResponse) {
		
		return translateArea(viewportResponse);
	}

	private Area translateBounds(Optional<com.netia.zadanie23.ResponseModel.Area> boundsResponse) {
		
		return translateArea(boundsResponse);
	}

	private Area translateArea(Optional<com.netia.zadanie23.ResponseModel.Area> areaResponse) {

		Area areaDbModel = new Area();
		
		if(areaResponse.isPresent())
		{
			areaDbModel.setSouthWest(translateLocation(areaResponse.get().getSouthWest()));
			areaDbModel.setNorthEast(translateLocation(areaResponse.get().getNorthEast()));
			
		}

		return areaDbModel;
	}

}
